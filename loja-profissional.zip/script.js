let carrinho = [];
function comprar(produto, valor) {
  carrinho.push({ produto, valor });
  atualizarCarrinho();
}
function atualizarCarrinho() {
  const ul = document.getElementById('carrinho');
  ul.innerHTML = '';
  let total = 0;
  carrinho.forEach(item => {
    total += item.valor;
    const li = document.createElement('li');
    li.textContent = `${item.produto} - R$ ${item.valor.toFixed(2)}`;
    ul.appendChild(li);
  });
  document.getElementById('total').textContent = total.toFixed(2);
}
function pagarAgora(tipo) {
  const total = carrinho.reduce((s, item) => s + item.valor, 0);
  const produto = 'Compra NovaShop';
  fetch(`/api/criarPagamento${tipo.charAt(0).toUpperCase() + tipo.slice(1)}`, {
    method: 'POST',
    body: JSON.stringify({ produto, valor: total })
  })
  .then(res => res.json())
  .then(data => {
    if (data.init_point) window.location.href = data.init_point;
    else if (data.link) window.location.href = data.link;
  });
}
